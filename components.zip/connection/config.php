<?php
    $db_host = "localhost";
    $db_username = "matakailcom_kefi";
    $db_password = "Matakail123#";
    $db_name = "matakailcom_kefi_ingredient";
    $base_url = "/ingredient/";
?>